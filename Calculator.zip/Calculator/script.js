const btnsele = document.querySelectorAll("button");
// console.log(btnsele);

const inputEle = document.getElementById("result");

for (let i = 0; i < btnsele.length; i++) {
  btnsele[i].addEventListener("click", () => {
    //    console.log( btnsele[i].textContent);
    const btnValue = btnsele[i].textContent
    if(btnValue === "C"){
        clearResult()
    }
    else if(btnValue === "="){
        calculateResult()
    }
    else{
        appendValue(btnValue)
    }
  });
}

function clearResult(){
    inputEle.value = ""
}

function calculateResult(){
    inputEle.value = eval(inputEle.value)
}

function appendValue(btnValue){
    inputEle.value += btnValue
}